﻿namespace Sistema_de_Gerenciamento_de_Produtos
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtSenha = new TextBox();
            txtEmail = new TextBox();
            txtUsuario = new TextBox();
            btnLogar = new MaterialSkin.Controls.MaterialButton();
            linkTelaCad = new LinkLabel();
            pictureBox1 = new PictureBox();
            linkEsqueciSenha = new LinkLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(408, 206);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 1;
            label1.Text = "E-mail:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(408, 259);
            label2.Name = "label2";
            label2.Size = new Size(46, 15);
            label2.TabIndex = 2;
            label2.Text = "Senha:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(400, 164);
            label3.Name = "label3";
            label3.Size = new Size(54, 15);
            label3.TabIndex = 3;
            label3.Text = "Usuario:";
            // 
            // txtSenha
            // 
            txtSenha.Cursor = Cursors.IBeam;
            txtSenha.Location = new Point(351, 277);
            txtSenha.Name = "txtSenha";
            txtSenha.PasswordChar = '*';
            txtSenha.Size = new Size(174, 21);
            txtSenha.TabIndex = 3;
            // 
            // txtEmail
            // 
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.Location = new Point(351, 224);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(174, 21);
            txtEmail.TabIndex = 2;
            // 
            // txtUsuario
            // 
            txtUsuario.Cursor = Cursors.IBeam;
            txtUsuario.Location = new Point(351, 182);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(174, 21);
            txtUsuario.TabIndex = 1;
            // 
            // btnLogar
            // 
            btnLogar.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnLogar.Cursor = Cursors.Hand;
            btnLogar.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            btnLogar.Depth = 0;
            btnLogar.HighEmphasis = true;
            btnLogar.Icon = null;
            btnLogar.Location = new Point(400, 307);
            btnLogar.Margin = new Padding(4, 6, 4, 6);
            btnLogar.MouseState = MaterialSkin.MouseState.HOVER;
            btnLogar.Name = "btnLogar";
            btnLogar.NoAccentTextColor = Color.Empty;
            btnLogar.Size = new Size(68, 36);
            btnLogar.TabIndex = 4;
            btnLogar.Text = "Logar";
            btnLogar.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            btnLogar.UseAccentColor = false;
            btnLogar.UseVisualStyleBackColor = true;
            btnLogar.Click += btnLogar_Click_1;
            // 
            // linkTelaCad
            // 
            linkTelaCad.ActiveLinkColor = Color.MediumPurple;
            linkTelaCad.AutoSize = true;
            linkTelaCad.LinkColor = Color.Purple;
            linkTelaCad.Location = new Point(394, 349);
            linkTelaCad.Name = "linkTelaCad";
            linkTelaCad.Size = new Size(76, 15);
            linkTelaCad.TabIndex = 5;
            linkTelaCad.TabStop = true;
            linkTelaCad.Text = "Cadastre-se";
            linkTelaCad.LinkClicked += linkTelaCad_LinkClicked;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.png_clipart_computer_icons_login_icon_design_others_logo_silhouette_thumbnail;
            pictureBox1.Location = new Point(-3, 66);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(869, 95);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // linkEsqueciSenha
            // 
            linkEsqueciSenha.ActiveLinkColor = Color.MediumPurple;
            linkEsqueciSenha.AutoSize = true;
            linkEsqueciSenha.LinkColor = Color.Purple;
            linkEsqueciSenha.Location = new Point(369, 376);
            linkEsqueciSenha.Name = "linkEsqueciSenha";
            linkEsqueciSenha.Size = new Size(128, 15);
            linkEsqueciSenha.TabIndex = 7;
            linkEsqueciSenha.TabStop = true;
            linkEsqueciSenha.Text = "Esqueci minha senha";
            linkEsqueciSenha.LinkClicked += linkEsqueciSenha_LinkClicked;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(863, 435);
            Controls.Add(linkEsqueciSenha);
            Controls.Add(pictureBox1);
            Controls.Add(linkTelaCad);
            Controls.Add(btnLogar);
            Controls.Add(txtUsuario);
            Controls.Add(txtEmail);
            Controls.Add(txtSenha);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Login";
            Padding = new Padding(3, 54, 3, 3);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            FormClosed += Login_FormClosed;
            Load += Login_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion


        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtSenha;
        private TextBox txtEmail;
        private TextBox txtUsuario;
        private MaterialSkin.Controls.MaterialButton btnLogar;
        private LinkLabel linkTelaCad;
        private PictureBox pictureBox1;
        private LinkLabel linkEsqueciSenha;
    }
}