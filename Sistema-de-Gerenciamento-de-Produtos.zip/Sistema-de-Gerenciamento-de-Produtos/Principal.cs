using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using MySql.Data.MySqlClient;
namespace Sistema_de_Gerenciamento_de_Produtos
{
    public partial class Principal : MaterialSkin.Controls.MaterialForm
    {
        private Usuarios usuarioLogado;
        public Principal(Usuarios usuarios)
        {
            InitializeComponent();
            caregarprodutos();

            usuarioLogado = usuarios;

            labelUsuario.Text = "Bem-vindo, " + usuarioLogado.USUARIO;

            //DataGridView
            Produtos produtos = new Produtos();
            dvgProdutos.AllowUserToAddRows = false;
            dvgProdutos.DataSource = produtos.listarTodos();
            dvgProdutos.AllowUserToAddRows = false;
            dvgProdutos.Columns["id"].Visible = false;
            dvgProdutos.Refresh();
            dvgProdutos.ClearSelection();
            dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;



            var skinManager = MaterialSkinManager.Instance;
            skinManager.AddFormToManage(this);
            skinManager.Theme = MaterialSkinManager.Themes.LIGHT;

            // Altere as cores aqui
            skinManager.ColorScheme = new ColorScheme(
                Primary.DeepPurple900,   // Barra de t�tulo
                Primary.DeepPurple600,   // Barra inferior (se usada)
                Primary.DeepPurple500,   // Detalhes/hover
                Accent.Purple200,
                TextShade.WHITE
            );

        }
        private void caregarprodutos()
        {
            comboCategoria.Items.Clear();
            comboCategoria.Items.Add("limpeza");
            comboCategoria.Items.Add("eletronicos");
            comboCategoria.Items.Add("moveis");
            comboCategoria.Items.Add("roupas");
            comboCategoria.Items.Add("brinquedos");
            comboCategoria.Items.Add("alimentos");
            comboCategoria.Items.Add("ferramentas");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();
            DataTable dt = produtos.listarTodos();
            dvgProdutos.AllowUserToAddRows = false;
            dvgProdutos.DataSource = produtos.listarTodos();
            dvgProdutos.AllowUserToAddRows = false;
            dvgProdutos.Columns["id"].Visible = false;
            dvgProdutos.Refresh();
            dvgProdutos.ClearSelection();
            dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        }



        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Principal_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void btntelacadastrar_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void txtPe�o_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(TxtNomeProduto.Text) && !string.IsNullOrEmpty(comboCategoria.Text) && !string.IsNullOrEmpty(txtPe�o.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
                {
                    Produtos produtos = new Produtos()
                    {
                        NOME = TxtNomeProduto.Text.Trim(),
                        CATEGORIA = comboCategoria.Text.Trim(),
                        PRECO = float.Parse(txtPe�o.Text.Trim()),
                        QUANTIDADE = txtQuantidade.Text.Trim()
                    };

                    produtos.iserirprodutos();
                    MessageBox.Show("Produto cadastrado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    dvgProdutos.DataSource = produtos.listarTodos();
                    dvgProdutos.AllowUserToAddRows = false;
                    dvgProdutos.Columns["id"].Visible = false;
                    dvgProdutos.Refresh();
                    dvgProdutos.ClearSelection();
                    dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    TxtNomeProduto.Clear();
                    comboCategoria.Text = "Escolha uma das categorias";
                    txtPe�o.Clear();
                    txtQuantidade.Clear();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar produto: " + ex.Message);
            }
        }

        private void dvgProdutos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dvgProdutos_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dvgProdutos.Rows[e.RowIndex];

                    txtID.Text = row.Cells["id"].Value.ToString();
                    TxtNomeProduto.Text = row.Cells["nome"].Value.ToString();
                    comboCategoria.Text = row.Cells["categoria"].Value.ToString();
                    txtPe�o.Text = row.Cells["preco"].Value.ToString();
                    txtQuantidade.Text = row.Cells["quantidade"].Value.ToString();

                }
                else
                {
                    MessageBox.Show("Selecione uma linha v�lida.", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao selecionar produto: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(TxtNomeProduto.Text) && !string.IsNullOrEmpty(comboCategoria.Text) && !string.IsNullOrEmpty(txtPe�o.Text) && !string.IsNullOrEmpty(txtQuantidade.Text))
                {
                    Produtos produtos = new Produtos()
                    {
                        ID = int.Parse(txtID.Text.Trim()),
                        NOME = TxtNomeProduto.Text.Trim(),
                        CATEGORIA = comboCategoria.Text.Trim(),
                        PRECO = float.Parse(txtPe�o.Text.Trim()),
                        QUANTIDADE = txtQuantidade.Text.Trim()
                    };
                    produtos.atualizarprodutos();
                    MessageBox.Show("Produto editado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    dvgProdutos.DataSource = produtos.listarTodos();
                    dvgProdutos.AllowUserToAddRows = false;
                    dvgProdutos.Columns["id"].Visible = false;
                    dvgProdutos.Refresh();
                    dvgProdutos.ClearSelection();
                    dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                    TxtNomeProduto.Clear();
                    comboCategoria.Text = "Escolha uma das categorias";
                    txtPe�o.Clear();
                    txtQuantidade.Clear();

                }
                else
                {
                    MessageBox.Show("Preencha todos os campos antes de editar.", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao editar produto: " + ex.Message, "ERRo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private int idProdutoSelecionado = 0;
        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (idProdutoSelecionado >= 0)
                {
                    Produtos produtos = new Produtos();
                    var result = MessageBox.Show("Tem certeza que deseja excluir este produto?", "Confirma��o", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        produtos.ID = int.Parse(txtID.Text.Trim());
                        produtos.excluirprodutos();
                        MessageBox.Show("Produto exclu�do com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        dvgProdutos.DataSource = produtos.listarTodos();
                        dvgProdutos.AllowUserToAddRows = false;
                        dvgProdutos.Columns["id"].Visible = false;
                        dvgProdutos.Refresh();
                        dvgProdutos.ClearSelection();
                        dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                        TxtNomeProduto.Clear();
                        comboCategoria.Text = "Escolha uma das categorias";
                        txtPe�o.Clear();
                        txtQuantidade.Clear();
                    }
                    else
                    {
                        if (result == DialogResult.No)
                        {
                            MessageBox.Show("Exclus�o cancelada!", "Aten��o", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            dvgProdutos.DataSource = produtos.listarTodos();
                            dvgProdutos.AllowUserToAddRows = false;
                            dvgProdutos.Columns["id"].Visible = false;
                            dvgProdutos.Refresh();
                            dvgProdutos.ClearSelection();
                            dvgProdutos.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                            TxtNomeProduto.Clear();
                            comboCategoria.Text = "Escolha uma das categorias";
                            txtPe�o.Clear();
                            txtQuantidade.Clear();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir produto: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void txtProduto_TextChanged(object sender, EventArgs e)
        {
            Produtos produtos = new Produtos();
            produtos.NOMEPORT = txtProduto.Text.Trim();
            dvgProdutos.DataSource = produtos.listarPorNome(TxtNomeProduto.Text);
        }
    }
}
