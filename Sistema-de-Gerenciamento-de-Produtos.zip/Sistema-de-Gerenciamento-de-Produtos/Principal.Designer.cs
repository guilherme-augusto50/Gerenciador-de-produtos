﻿namespace Sistema_de_Gerenciamento_de_Produtos
{
    partial class Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            panel1 = new Panel();
            labelUsuario = new Label();
            pictureBox1 = new PictureBox();
            btntelacadastrar = new Button();
            lblUsuarios = new Label();
            label2 = new Label();
            dvgProdutos = new DataGridView();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            TxtNomeProduto = new TextBox();
            txtPeço = new TextBox();
            txtQuantidade = new TextBox();
            comboCategoria = new ComboBox();
            btnCadastrar = new MaterialSkin.Controls.MaterialButton();
            btnEditar = new MaterialSkin.Controls.MaterialButton();
            btnExcluir = new MaterialSkin.Controls.MaterialButton();
            txtProduto = new TextBox();
            txtID = new TextBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dvgProdutos).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(panel1, "panel1");
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(labelUsuario);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btntelacadastrar);
            panel1.Controls.Add(lblUsuarios);
            panel1.Name = "panel1";
            panel1.Paint += panel1_Paint;
            // 
            // labelUsuario
            // 
            resources.ApplyResources(labelUsuario, "labelUsuario");
            labelUsuario.Name = "labelUsuario";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(pictureBox1, "pictureBox1");
            pictureBox1.Image = Properties.Resources._972105c5a775f38cf33d3924aea053f1;
            pictureBox1.Name = "pictureBox1";
            pictureBox1.TabStop = false;
            // 
            // btntelacadastrar
            // 
            resources.ApplyResources(btntelacadastrar, "btntelacadastrar");
            btntelacadastrar.BackColor = Color.Transparent;
            btntelacadastrar.FlatAppearance.BorderSize = 0;
            btntelacadastrar.Image = Properties.Resources.icon_regsitre;
            btntelacadastrar.Name = "btntelacadastrar";
            btntelacadastrar.UseVisualStyleBackColor = false;
            btntelacadastrar.Click += btntelacadastrar_Click;
            // 
            // lblUsuarios
            // 
            resources.ApplyResources(lblUsuarios, "lblUsuarios");
            lblUsuarios.ForeColor = Color.Red;
            lblUsuarios.Name = "lblUsuarios";
            lblUsuarios.Click += label1_Click;
            // 
            // label2
            // 
            resources.ApplyResources(label2, "label2");
            label2.Name = "label2";
            // 
            // dvgProdutos
            // 
            resources.ApplyResources(dvgProdutos, "dvgProdutos");
            dvgProdutos.AllowUserToAddRows = false;
            dvgProdutos.AllowUserToDeleteRows = false;
            dvgProdutos.AllowUserToOrderColumns = true;
            dvgProdutos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dvgProdutos.Cursor = Cursors.Cross;
            dvgProdutos.Name = "dvgProdutos";
            dvgProdutos.ReadOnly = true;
            dvgProdutos.CellContentClick += dvgProdutos_CellContentClick;
            dvgProdutos.CellContentDoubleClick += dvgProdutos_CellContentDoubleClick;
            // 
            // label3
            // 
            resources.ApplyResources(label3, "label3");
            label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(label4, "label4");
            label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(label5, "label5");
            label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(label6, "label6");
            label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(label7, "label7");
            label7.Name = "label7";
            // 
            // TxtNomeProduto
            // 
            resources.ApplyResources(TxtNomeProduto, "TxtNomeProduto");
            TxtNomeProduto.BorderStyle = BorderStyle.FixedSingle;
            TxtNomeProduto.Cursor = Cursors.IBeam;
            TxtNomeProduto.Name = "TxtNomeProduto";
            // 
            // txtPeço
            // 
            resources.ApplyResources(txtPeço, "txtPeço");
            txtPeço.BorderStyle = BorderStyle.FixedSingle;
            txtPeço.Cursor = Cursors.IBeam;
            txtPeço.Name = "txtPeço";
            txtPeço.TextChanged += txtPeço_TextChanged;
            // 
            // txtQuantidade
            // 
            resources.ApplyResources(txtQuantidade, "txtQuantidade");
            txtQuantidade.BorderStyle = BorderStyle.FixedSingle;
            txtQuantidade.Cursor = Cursors.IBeam;
            txtQuantidade.Name = "txtQuantidade";
            // 
            // comboCategoria
            // 
            resources.ApplyResources(comboCategoria, "comboCategoria");
            comboCategoria.FormattingEnabled = true;
            comboCategoria.Name = "comboCategoria";
            // 
            // btnCadastrar
            // 
            resources.ApplyResources(btnCadastrar, "btnCadastrar");
            btnCadastrar.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            btnCadastrar.Depth = 0;
            btnCadastrar.HighEmphasis = true;
            btnCadastrar.Icon = null;
            btnCadastrar.MouseState = MaterialSkin.MouseState.HOVER;
            btnCadastrar.Name = "btnCadastrar";
            btnCadastrar.NoAccentTextColor = Color.Empty;
            btnCadastrar.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            btnCadastrar.UseAccentColor = false;
            btnCadastrar.UseVisualStyleBackColor = true;
            btnCadastrar.Click += btnCadastrar_Click;
            // 
            // btnEditar
            // 
            resources.ApplyResources(btnEditar, "btnEditar");
            btnEditar.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            btnEditar.Depth = 0;
            btnEditar.HighEmphasis = true;
            btnEditar.Icon = null;
            btnEditar.MouseState = MaterialSkin.MouseState.HOVER;
            btnEditar.Name = "btnEditar";
            btnEditar.NoAccentTextColor = Color.Empty;
            btnEditar.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            btnEditar.UseAccentColor = false;
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnExcluir
            // 
            resources.ApplyResources(btnExcluir, "btnExcluir");
            btnExcluir.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            btnExcluir.Depth = 0;
            btnExcluir.HighEmphasis = true;
            btnExcluir.Icon = null;
            btnExcluir.MouseState = MaterialSkin.MouseState.HOVER;
            btnExcluir.Name = "btnExcluir";
            btnExcluir.NoAccentTextColor = Color.Empty;
            btnExcluir.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            btnExcluir.UseAccentColor = false;
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // txtProduto
            // 
            resources.ApplyResources(txtProduto, "txtProduto");
            txtProduto.BorderStyle = BorderStyle.FixedSingle;
            txtProduto.Name = "txtProduto";
            txtProduto.TextChanged += txtProduto_TextChanged;
            // 
            // txtID
            // 
            resources.ApplyResources(txtID, "txtID");
            txtID.BackColor = SystemColors.ButtonShadow;
            txtID.BorderStyle = BorderStyle.FixedSingle;
            txtID.Cursor = Cursors.No;
            txtID.Name = "txtID";
            // 
            // Principal
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = SystemColors.ControlLightLight;
            Controls.Add(txtID);
            Controls.Add(txtProduto);
            Controls.Add(btnExcluir);
            Controls.Add(btnEditar);
            Controls.Add(btnCadastrar);
            Controls.Add(comboCategoria);
            Controls.Add(txtQuantidade);
            Controls.Add(txtPeço);
            Controls.Add(TxtNomeProduto);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(dvgProdutos);
            Controls.Add(label2);
            Controls.Add(panel1);
            ForeColor = Color.Black;
            FormBorderStyle = FormBorderStyle.Sizable;
            FormStyle = FormStyles.ActionBar_None;
            Name = "Principal";
            Sizable = false;
            FormClosed += Principal_FormClosed;
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dvgProdutos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Label lblUsuarios;
        private Label label2;
        private DataGridView dvgProdutos;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox TxtNomeProduto;
        private TextBox txtPeço;
        private TextBox txtQuantidade;
        private ComboBox comboCategoria;
        private MaterialSkin.Controls.MaterialButton btnCadastrar;
        private MaterialSkin.Controls.MaterialButton btnEditar;
        private MaterialSkin.Controls.MaterialButton btnExcluir;
        private TextBox txtProduto;
        private PictureBox pictureBox1;
        private Button btntelacadastrar;
        private Label labelUsuario;
        private TextBox txtID;
    }
}
