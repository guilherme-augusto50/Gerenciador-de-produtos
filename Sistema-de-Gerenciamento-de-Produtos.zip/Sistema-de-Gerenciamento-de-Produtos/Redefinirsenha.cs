﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sistema_de_Gerenciamento_de_Produtos
{
    public partial class Redefinirsenha : MaterialSkin.Controls.MaterialForm
    {
        public Redefinirsenha()
        {
            InitializeComponent();
        }

        private void Redefinirsenha_Load(object sender, EventArgs e)
        {

        }

        private void Redefinirsenha_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnRedSenha_Click(object sender, EventArgs e)
        {
            try {
                Usuarios usuario = new Usuarios();
                string email = txtEmail.Text.Trim();
                string senha = txtSenha.Text.Trim();
                if (!string.IsNullOrEmpty(email) || !string.IsNullOrEmpty(senha))
                {
                    if (!Usuarios.VerificarEmail(txtEmail.Text))
                    {
                        MessageBox.Show("Email inválido!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    bool sucesso = usuario.redefinirsenha(email, senha);
                    if (sucesso) { 
                        MessageBox.Show("Senha redefinida com sucesso!", "SUCESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Login log = new Login();
                        log.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao redefinir a senha: " + ex.Message, "Erro - Método Redefinir Senha", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void linkTelaLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Login log = new Login();
            log.Show();
            this.Hide();
        }
    }
}
