﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;
using MySql.Data.MySqlClient;

namespace Sistema_de_Gerenciamento_de_Produtos
{
    public partial class Login : MaterialSkin.Controls.MaterialForm
    {
        public Login()
        {
            InitializeComponent();

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogar_Click(object sender, EventArgs e)
        {

        }

        private void btnLogar_Click_1(object sender, EventArgs e)
        {
            Usuarios usuarios = new Usuarios() {
                EMAIL = txtEmail.Text.Trim(),
                SENHA = txtSenha.Text.Trim(),
                USUARIO = txtUsuario.Text.Trim()
            };

            Usuarios usuariologado = usuarios.login();
            usuariologado = usuarios.login();
            if (usuariologado != null)
            {
                MessageBox.Show("Login realizado com sucesso!", "Bem-vindo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Principal principal = new Principal(usuariologado);
                principal.Show();
                this.Hide();
            }

        }

        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void linkTelaCad_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            CadastrodeUsuarios cad = new CadastrodeUsuarios();
            cad.Show();
            this.Hide();
        }

        private void linkEsqueciSenha_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Redefinirsenha red = new Redefinirsenha();
            red.Show();
            this.Hide();
        }
    }
}
