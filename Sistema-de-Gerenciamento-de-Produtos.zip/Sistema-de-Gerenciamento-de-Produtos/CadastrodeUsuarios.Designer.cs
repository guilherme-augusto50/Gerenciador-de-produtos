﻿namespace Sistema_de_Gerenciamento_de_Produtos
{
    partial class CadastrodeUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrodeUsuarios));
            materialLabel1 = new MaterialSkin.Controls.MaterialLabel();
            materialLabel2 = new MaterialSkin.Controls.MaterialLabel();
            materialLabel3 = new MaterialSkin.Controls.MaterialLabel();
            materialLabel4 = new MaterialSkin.Controls.MaterialLabel();
            materialLabel5 = new MaterialSkin.Controls.MaterialLabel();
            bntCadastro = new MaterialSkin.Controls.MaterialButton();
            MaskedCpf = new MaskedTextBox();
            txtSenha = new TextBox();
            txtNome = new TextBox();
            txtEmail = new TextBox();
            txtUsuario = new TextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // materialLabel1
            // 
            materialLabel1.AutoSize = true;
            materialLabel1.Depth = 0;
            materialLabel1.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel1.Location = new Point(6, 170);
            materialLabel1.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel1.Name = "materialLabel1";
            materialLabel1.Size = new Size(47, 19);
            materialLabel1.TabIndex = 0;
            materialLabel1.Text = "Nome:";
            // 
            // materialLabel2
            // 
            materialLabel2.AutoSize = true;
            materialLabel2.Depth = 0;
            materialLabel2.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel2.Location = new Point(8, 244);
            materialLabel2.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel2.Name = "materialLabel2";
            materialLabel2.Size = new Size(45, 19);
            materialLabel2.TabIndex = 1;
            materialLabel2.Text = "Email:";
            // 
            // materialLabel3
            // 
            materialLabel3.AutoSize = true;
            materialLabel3.Depth = 0;
            materialLabel3.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel3.Location = new Point(395, 170);
            materialLabel3.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel3.Name = "materialLabel3";
            materialLabel3.Size = new Size(34, 19);
            materialLabel3.TabIndex = 2;
            materialLabel3.Text = "CPF:";
            // 
            // materialLabel4
            // 
            materialLabel4.AutoSize = true;
            materialLabel4.Depth = 0;
            materialLabel4.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel4.Location = new Point(395, 244);
            materialLabel4.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel4.Name = "materialLabel4";
            materialLabel4.Size = new Size(59, 19);
            materialLabel4.TabIndex = 3;
            materialLabel4.Text = "Usuario:";
            // 
            // materialLabel5
            // 
            materialLabel5.AutoSize = true;
            materialLabel5.Depth = 0;
            materialLabel5.Font = new Font("Roboto", 14F, FontStyle.Regular, GraphicsUnit.Pixel);
            materialLabel5.Location = new Point(574, 170);
            materialLabel5.MouseState = MaterialSkin.MouseState.HOVER;
            materialLabel5.Name = "materialLabel5";
            materialLabel5.Size = new Size(50, 19);
            materialLabel5.TabIndex = 4;
            materialLabel5.Text = "Senha:";
            // 
            // bntCadastro
            // 
            bntCadastro.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            bntCadastro.Cursor = Cursors.Hand;
            bntCadastro.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            bntCadastro.Depth = 0;
            bntCadastro.HighEmphasis = true;
            bntCadastro.Icon = null;
            bntCadastro.Location = new Point(369, 338);
            bntCadastro.Margin = new Padding(4, 6, 4, 6);
            bntCadastro.MouseState = MaterialSkin.MouseState.HOVER;
            bntCadastro.Name = "bntCadastro";
            bntCadastro.NoAccentTextColor = Color.Empty;
            bntCadastro.Size = new Size(97, 36);
            bntCadastro.TabIndex = 5;
            bntCadastro.Text = "Cadastro";
            bntCadastro.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            bntCadastro.UseAccentColor = false;
            bntCadastro.UseVisualStyleBackColor = true;
            bntCadastro.Click += bntCadastro_Click;
            // 
            // MaskedCpf
            // 
            MaskedCpf.Cursor = Cursors.IBeam;
            MaskedCpf.Location = new Point(395, 192);
            MaskedCpf.Mask = "000,000,000-00,";
            MaskedCpf.Name = "MaskedCpf";
            MaskedCpf.Size = new Size(153, 23);
            MaskedCpf.TabIndex = 6;
            // 
            // txtSenha
            // 
            txtSenha.Cursor = Cursors.IBeam;
            txtSenha.Location = new Point(574, 192);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(276, 23);
            txtSenha.TabIndex = 7;
            // 
            // txtNome
            // 
            txtNome.Cursor = Cursors.IBeam;
            txtNome.Location = new Point(6, 192);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(352, 23);
            txtNome.TabIndex = 8;
            txtNome.TextChanged += textBox2_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.Location = new Point(6, 266);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(361, 23);
            txtEmail.TabIndex = 9;
            // 
            // txtUsuario
            // 
            txtUsuario.Cursor = Cursors.IBeam;
            txtUsuario.Location = new Point(395, 266);
            txtUsuario.Name = "txtUsuario";
            txtUsuario.Size = new Size(231, 23);
            txtUsuario.TabIndex = 10;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Top;
            pictureBox1.Image = Properties.Resources.th;
            pictureBox1.Location = new Point(3, 64);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(873, 103);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // CadastrodeUsuarios
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(879, 414);
            Controls.Add(pictureBox1);
            Controls.Add(txtUsuario);
            Controls.Add(txtEmail);
            Controls.Add(txtNome);
            Controls.Add(txtSenha);
            Controls.Add(MaskedCpf);
            Controls.Add(bntCadastro);
            Controls.Add(materialLabel5);
            Controls.Add(materialLabel4);
            Controls.Add(materialLabel3);
            Controls.Add(materialLabel2);
            Controls.Add(materialLabel1);
            Font = new Font("Arial", 10F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "CadastrodeUsuarios";
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Cadastro de Usuarios";
            TopMost = true;
            FormClosed += CadastrodeUsuarios_FormClosed;
            Load += CadastrodeUsuarios_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MaterialSkin.Controls.MaterialLabel materialLabel1;
        private MaterialSkin.Controls.MaterialLabel materialLabel2;
        private MaterialSkin.Controls.MaterialLabel materialLabel3;
        private MaterialSkin.Controls.MaterialLabel materialLabel4;
        private MaterialSkin.Controls.MaterialLabel materialLabel5;
        private MaterialSkin.Controls.MaterialButton bntCadastro;
        private MaskedTextBox MaskedCpf;
        private TextBox txtSenha;
        private TextBox txtNome;
        private TextBox txtEmail;
        private TextBox txtUsuario;
        private PictureBox pictureBox1;
    }
}