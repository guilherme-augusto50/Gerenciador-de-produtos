﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions; 

namespace Sistema_de_Gerenciamento_de_Produtos
{
    public partial class CadastrodeUsuarios : MaterialSkin.Controls.MaterialForm
    {
        public CadastrodeUsuarios()
        {
            InitializeComponent();
        }

        private void CadastrodeUsuarios_Load(object sender, EventArgs e)
        {

        }

        private void materialLabel1_Click(object sender, EventArgs e)
        {

        }

        private void materialMaskedTextBox2_Click(object sender, EventArgs e)
        {

        }

        private void MaskedCPF_Click(object sender, EventArgs e)
        {


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bntCadastro_Click(object sender, EventArgs e)
        {
            try
            {
                if (!txtNome.Text.Equals("") && !txtEmail.Text.Equals("") && !txtUsuario.Text.Equals("") && !txtSenha.Text.Equals("") && !MaskedCpf.Text.Equals(""))
                {
                    string cpfLimpo = Regex.Replace(MaskedCpf.Text, "[^0-9]", "");


                    if (!Usuarios.CpfValidado(cpfLimpo))
                    {
                        MessageBox.Show("CPF inválido!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    if (!Usuarios.VerificarEmail(txtEmail.Text))
                    {
                        MessageBox.Show("Email inválido!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (Usuarios.Usuarioexistente(txtEmail.Text, cpfLimpo))
                    {
                        MessageBox.Show("E-mail ou CPF já estão cadastrados!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    Usuarios usuarios = new Usuarios();
                    usuarios.Nome = txtNome.Text.Trim();
                    usuarios.EMAIL = txtEmail.Text.Trim();
                    usuarios.CPF = cpfLimpo;
                    usuarios.USUARIO = txtUsuario.Text.Trim();
                    usuarios.SENHA = Usuarios.CriptografarSenha(txtSenha.Text.Trim());

                    if (usuarios.cadastro())
                    {
                        MessageBox.Show("Usuário cadastrado com sucesso!", "SUCESSO", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Login login = new Login();
                        login.Show();
                        this.Hide();
                        txtNome.Clear();
                        txtEmail.Clear();
                        txtUsuario.Clear();
                        txtSenha.Clear();
                        MaskedCpf.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Erro ao cadastrar usuário!", "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Preencha todos os campos!", "ATENÇÃO", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao cadastrar: " + ex.Message, "ERRO", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void CadastrodeUsuarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
