﻿namespace Sistema_de_Gerenciamento_de_Produtos
{
    partial class Redefinirsenha
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Redefinirsenha));
            label1 = new Label();
            label2 = new Label();
            txtEmail = new TextBox();
            txtSenha = new TextBox();
            btnRedSenha = new MaterialSkin.Controls.MaterialButton();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            linkTelaLogin = new LinkLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(351, 144);
            label1.Name = "label1";
            label1.Size = new Size(46, 15);
            label1.TabIndex = 0;
            label1.Text = "E-mail:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(342, 186);
            label2.Name = "label2";
            label2.Size = new Size(76, 15);
            label2.TabIndex = 1;
            label2.Text = "Nova senha:";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(293, 162);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "Example@exampe.com.br";
            txtEmail.Size = new Size(187, 21);
            txtEmail.TabIndex = 2;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(293, 204);
            txtSenha.Name = "txtSenha";
            txtSenha.PlaceholderText = "EX:Senha123";
            txtSenha.Size = new Size(187, 21);
            txtSenha.TabIndex = 3;
            // 
            // btnRedSenha
            // 
            btnRedSenha.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            btnRedSenha.Density = MaterialSkin.Controls.MaterialButton.MaterialButtonDensity.Default;
            btnRedSenha.Depth = 0;
            btnRedSenha.HighEmphasis = true;
            btnRedSenha.Icon = null;
            btnRedSenha.Location = new Point(302, 255);
            btnRedSenha.Margin = new Padding(4, 6, 4, 6);
            btnRedSenha.MouseState = MaterialSkin.MouseState.HOVER;
            btnRedSenha.Name = "btnRedSenha";
            btnRedSenha.NoAccentTextColor = Color.Empty;
            btnRedSenha.Size = new Size(145, 36);
            btnRedSenha.TabIndex = 4;
            btnRedSenha.Text = "Redefinir senha";
            btnRedSenha.Type = MaterialSkin.Controls.MaterialButton.MaterialButtonType.Contained;
            btnRedSenha.UseAccentColor = false;
            btnRedSenha.UseVisualStyleBackColor = true;
            btnRedSenha.Click += btnRedSenha_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = Properties.Resources.nova_senha_login;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(743, 100);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(3, 24);
            panel1.Name = "panel1";
            panel1.Size = new Size(743, 100);
            panel1.TabIndex = 7;
            panel1.Paint += panel1_Paint;
            // 
            // linkTelaLogin
            // 
            linkTelaLogin.ActiveLinkColor = Color.Fuchsia;
            linkTelaLogin.AutoSize = true;
            linkTelaLogin.LinkColor = Color.Purple;
            linkTelaLogin.Location = new Point(323, 297);
            linkTelaLogin.Name = "linkTelaLogin";
            linkTelaLogin.Size = new Size(95, 15);
            linkTelaLogin.TabIndex = 8;
            linkTelaLogin.TabStop = true;
            linkTelaLogin.Text = "Voltar para login";
            linkTelaLogin.LinkClicked += linkTelaLogin_LinkClicked;
            // 
            // Redefinirsenha
            // 
            AutoScaleDimensions = new SizeF(96F, 96F);
            AutoScaleMode = AutoScaleMode.Dpi;
            ClientSize = new Size(749, 469);
            Controls.Add(linkTelaLogin);
            Controls.Add(panel1);
            Controls.Add(btnRedSenha);
            Controls.Add(txtSenha);
            Controls.Add(txtEmail);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            FormBorderStyle = FormBorderStyle.Fixed3D;
            FormStyle = FormStyles.ActionBar_None;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Redefinirsenha";
            Padding = new Padding(3, 24, 3, 3);
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += Redefinirsenha_FormClosed;
            Load += Redefinirsenha_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtEmail;
        private TextBox txtSenha;
        private MaterialSkin.Controls.MaterialButton btnRedSenha;
        private PictureBox pictureBox1;
        private Panel panel1;
        private LinkLabel linkTelaLogin;
    }
}