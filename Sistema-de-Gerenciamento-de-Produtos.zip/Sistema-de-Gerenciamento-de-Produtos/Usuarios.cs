﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;

namespace Sistema_de_Gerenciamento_de_Produtos
{
    public class Usuarios
    {
        public string nome;
        public string Email;
        public string senha;
        public string cpf;
        public string usuario;
        public int id;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }
        public string EMAIL
        {
            get { return Email; }
            set { Email = value; }
        }
        public string SENHA
        {
            get { return senha; }
            set { senha = value; }
        }
        public string CPF
        {
            get { return cpf; }
            set { cpf = value; }
        }
        public string USUARIO
        {
            get { return usuario; }
            set { usuario = value; }
        }

        public static bool VerificarEmail(string Email)
        {
            string emailValido = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";
            Regex regex = new Regex(emailValido);
            return regex.IsMatch(Email);
        }
        public static string CriptografarSenha(string senha)
        {
            try
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(senha));
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        builder.Append(bytes[i].ToString("x2"));
                    }

                    return builder.ToString();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível criptografar a senha: " + ex.Message, "Erro - Método Criptografar", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "";
            }
        }
        public static bool CpfValidado(string cpf)
        {
            cpf = cpf.Replace(",", "").Replace("-", "").Trim();

            if (cpf.Length != 11 || !cpf.All(char.IsDigit) || cpf.Distinct().Count() == 1)
                return false;

            int[] mult1 = { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] mult2 = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            string tempCpf = cpf.Substring(0, 9);
            int soma = 0;

            for (int i = 0; i < 9; i++)
                soma += int.Parse(tempCpf[i].ToString()) * mult1[i];

            int resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;
            string digito = resto.ToString();

            tempCpf += digito;
            soma = 0;

            for (int i = 0; i < 10; i++)
                soma += int.Parse(tempCpf[i].ToString()) * mult2[i];

            resto = soma % 11;
            resto = resto < 2 ? 0 : 11 - resto;
            digito += resto.ToString();

            return cpf.EndsWith(digito);
        }
        public static bool Usuarioexistente(string email, string cpf) {
                try {
                    using (MySqlConnection conexao = new conexaoBD().Conectar())
                    {
                        string usuarioExistente = "SELECT COUNT(*) FROM usuarios WHERE email = @email OR cpf = @cpf";
                        MySqlCommand cmd = new MySqlCommand(usuarioExistente, conexao);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@cpf", cpf);

                        int cont = Convert.ToInt32(cmd.ExecuteScalar());
                        return cont > 0;
                    }
                }
            catch (Exception ex) {
                MessageBox.Show("Erro ao verificar usuário existente: " + ex.Message, "Erro - Método Usuarioexistente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return true;
            }
        }
        public bool cadastro()
        {
            try {
                using (MySqlConnection conexao = new conexaoBD().Conectar())
                {
                    string verificarCpf = CpfValidado(CPF) ? CPF : throw new Exception("CPF inválido");
                    string verificarEmail = VerificarEmail(EMAIL) ? EMAIL : throw new Exception("Email inválido");
                    string senhaCriptografada = CriptografarSenha(SENHA);
                    string usuario = "INSERT INTO usuarios (nome, email, cpf, usuario, senha) VALUES (@nome, @email, @cpf ,@usuario, @senha)";
                    MySqlCommand cmd = new MySqlCommand(usuario, conexao);
                    cmd.Parameters.AddWithValue("@nome", Nome);
                    cmd.Parameters.AddWithValue("@email", verificarEmail);
                    cmd.Parameters.AddWithValue("@cpf", verificarCpf);
                    cmd.Parameters.AddWithValue("@usuario", USUARIO);
                    cmd.Parameters.AddWithValue("@senha", senhaCriptografada); 

                    int resultado = cmd.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao cadastrar usuário: " + ex.Message);
                return false;
            }
        }

        public bool redefinirsenha(string Email, string novasenha)
        {
            try {
                using(MySqlConnection conectar = new conexaoBD().Conectar())
                {
                    string senhacriptografada = CriptografarSenha(novasenha);

                    string redefinir = "UPDATE usuarios SET senha = @senha WHERE email = @email";
                    MySqlCommand cmd = new MySqlCommand(redefinir, conectar);
                    cmd.Parameters.AddWithValue("@senha", senhacriptografada);
                    cmd.Parameters.AddWithValue("@email", Email);

                    int resultado = cmd.ExecuteNonQuery();
                    return resultado > 0;


                }
            } catch(Exception ex) {
                MessageBox.Show("Erro ao redefinir senha: " + ex.Message, "Erro - Método redefinirsenha", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        public Usuarios login()
        {
            try {
                using (MySqlConnection conexao = new conexaoBD().Conectar()) {
                    string sql = "SELECT * FROM usuarios WHERE email = @email OR usuario = @usuario ";
                    MySqlCommand cmd = new MySqlCommand(sql, conexao);
                    cmd.Parameters.AddWithValue("@usuario", USUARIO);
                    cmd.Parameters.AddWithValue("@email", EMAIL);

                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        string senhaHash = reader["senha"].ToString();
                        string senhacripitografada = CriptografarSenha(SENHA);
                        if (senhaHash == senhacripitografada)
                        {
                            Usuarios usuario = new Usuarios() {
                                ID = Convert.ToInt32(reader["id"]),
                                Nome = reader["nome"].ToString(),
                                EMAIL = reader["email"].ToString(),
                                CPF = reader["cpf"].ToString(),
                                USUARIO = reader["usuario"].ToString(),
                                SENHA = senhaHash 
                            };
                            return usuario;
                        }
                        MessageBox.Show("Usuário ou senha inválidos", "Erro - Método login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }

                    else
                    {
                        MessageBox.Show("Usuário ou senha inválidos", "Erro - Método login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return null;
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Erro ao fazer login: " + ex.Message, "Erro - Método login", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }

        }
    }
}
