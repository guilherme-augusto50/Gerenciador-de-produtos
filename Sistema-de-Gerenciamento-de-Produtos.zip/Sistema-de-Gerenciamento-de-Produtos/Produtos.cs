﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Sistema_de_Gerenciamento_de_Produtos
{
    internal class Produtos
    {
        int id;
        string nome;
        string categoria;
        float preco;
        string quatindade;
        string nomeport;

        public int ID
        {
            get { return id; }
            set { id = value; }
        }
        public string NOME
        {
            get { return nome; }
            set { nome = value; }
        }
        public string CATEGORIA
        {
            get { return categoria; }
            set { categoria = value; }
        }
        public float PRECO
        {
            get { return preco; }
            set { preco = value; }
        }
        public string QUANTIDADE
        {
            get { return quatindade; }
            set { quatindade = value; }
        }
        public string NOMEPORT
        {
            get { return nomeport; }
            set { nomeport = value; }
        }

        public bool iserirprodutos() {
            try {
                using (MySqlConnection conexao = new conexaoBD().Conectar())
                {
                    string produtos = "INSERT INTO produtos (nome, preco, quantidade, categoria) VALUES (@nome, @quantidade, @preco, @categoria)";
                    MySqlCommand cmd = new MySqlCommand(produtos, conexao);
                    cmd.Parameters.AddWithValue("@nome", NOME);
                    cmd.Parameters.AddWithValue("@quantidade", QUANTIDADE);
                    cmd.Parameters.AddWithValue("@preco", PRECO);
                    cmd.Parameters.AddWithValue("@categoria", CATEGORIA);
                    int resultado = cmd.ExecuteNonQuery();
                    if (resultado > 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao inserir produto: " + ex.Message);
                return false;
            }
        }
        public void excluirprodutos()
        {
            try
            {
                using (MySqlConnection conexao = new conexaoBD().Conectar())
                {
                    string produtos = "DELETE FROM produtos WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(produtos, conexao);
                    cmd.Parameters.AddWithValue("@id", ID);
                    cmd.ExecuteNonQuery();
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao excluir produto: " + ex.Message);
            }
        }
        public void atualizarprodutos()
        {
            try
            {
                using (MySqlConnection conexao = new conexaoBD().Conectar())
                {
                    string produtos = "UPDATE produtos SET nome = @nome, preco = @preco, categoria = @categoria, quantidade = @quantidade WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(produtos, conexao);
                    cmd.Parameters.AddWithValue("@nome", NOME);
                    cmd.Parameters.AddWithValue("@preco", PRECO);
                    cmd.Parameters.AddWithValue("@categoria", CATEGORIA);
                    cmd.Parameters.AddWithValue("@quantidade", QUANTIDADE);
                    cmd.Parameters.AddWithValue("@id", ID);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao atualizar produto: " + ex.Message);
            }
        }
        public DataTable listarTodos() {
            DataTable dt = new DataTable();
            using (MySqlConnection conxeao = new conexaoBD().Conectar())
            {
                try { 
                    string produtos = "SELECT * FROM produtos";
                    MySqlCommand cmd = new MySqlCommand(produtos, conxeao);
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dt);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao listar produtos: " + ex.Message);
                }
            }
            return dt;
        }
        public DataTable listarPorNome(string nome) {
            DataTable dataTable = new DataTable();
            using (MySqlConnection conexao = new conexaoBD().Conectar())
            {
                try { 
                    string produtos = "SELECT * FROM produtos WHERE nome LIKE @nome";
                    MySqlCommand cmd = new MySqlCommand(produtos, conexao);
                    cmd.Parameters.AddWithValue("@nome", "%" + NOMEPORT + "%");
                    MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                    da.Fill(dataTable);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao listar produtos por nome: " + ex.Message);
                }

            }
            return dataTable;
        }
    }
}
